#include <iostream>
#include <math.h>
using namespace std;

int main(int argc, char** argv) {
	
	int a,b,c,i;
	cin>>a>>b;
	
	for(i=1;i<=a+b;i++){
		if(a%i==0 and b%i==0){
			c=i;
		}
	}
	cout<<"最大公因數是"<<c;
	
	return 0;
}

