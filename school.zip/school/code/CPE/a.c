#include <iostream>
using namespace std;
int main(void)
{
    int num[3];
    cin>>num[0];
    cin>>num[1];
    cin>>num[2];
}