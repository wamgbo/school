function go(){
    var a=1;    
    alert(a);
}
function go1(){
    var x = document.getElementById("in").value;
    var y = document.getElementById("out1");
    var z = document.getElementById("out2");
    y.innerHTML = x + " 您好~";
    z.textContent = "haaaaaaaaaaaaaaaaaaaaaaaaaaaaa!";
}
function trans(x) {
    x.src="gif/dumbass.gif";
}
function normal(x) {
    x.src="pic/dumbass.png";
}