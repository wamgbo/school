grep "^set bell-style" /etc/inputrc
set bell-style none
