import java.util.*;
class Employee{
    private String name;
    private String position;
    private int year;   
    private int money;
    Employee(String name,String position)
    {
        this(name, position, 1);
    }    
    Employee(String name,int year)
    {
        this(name,"一般員工", year);
    }
    Employee(String name,String position,int year){
        setName(name);
        setPosition(position);
        setYear(year);
        checkPosition();
        checkYear();
        setMoney();
    }
    public void checkPosition()
    {
        String defaultPosition[]=new String[]{"一般員工","主管","部長"};
        for(String words:defaultPosition)
        {
            if(this.position!=words)
            {
                this.position="一般員工";       
                return;
            }
        }
    }
    public void checkYear()
    {
        if(this.year<0||this.year>15)
            this.year=1;   
    }
    public int yearMoney()
    {
        if(this.year<=5)
            return 2000;
        else if(this.year>5&&this.year<=10)
            return 6000;
        else
            return 12000;
    }
    public void setMoney()
    {
        switch (this.name) {
            case "一般員工":
                this.money=22000+yearMoney();
                break;
            case "主管":
                this.money=40000+yearMoney();
                break;
            case "部長":
                this.money=55000+yearMoney();
                break;
        }   
    }
    public void show()
    {
        System.out.println("姓名："+this.name+"，職位："+this.position+"，年資："+this.year+"，月薪："+this.money);
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
}

public class main {
    public static void input(String name[],String position[],int year[],String information[])
    {
        name[0]=information[0];
        if (information.length == 2) {
            if (information[1].charAt(0) >= '0' && information[1].charAt(0) <= '9')
                year[0] = Integer.parseInt(information[1]);
            else
                position[0]=information[1];
        }
        else
        {
            position[0]=information[1];
            year[0] = Integer.parseInt(information[2]);
        }                   
    }
    public void depend(Employee employee)
    {
        
    }
    public static void main(String args[])
    {
        Scanner s=new Scanner(System.in);
        String register=s.nextLine();
        String information[]=register.split(",");

        String name[]=new String[2];   
        String position[]=new String[2];   
        int year[]=new int[2];   

        input(name,position,year,information);
        if(information.length==3)
        {
            Employee employee=new Employee(name[0],position[0],year[0]);
        }
        else
        {

        }

    }
    
}